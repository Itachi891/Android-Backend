const { Schema, default: mongoose } = require('mongoose')

const StockSchema = Schema({

    sizingId: {

        type: mongoose.Schema.Types.ObjectId,
        ref: 'Sizing'
    },

    clientId: {

        type: mongoose.Schema.Types.ObjectId,
        ref: 'Clients'
    },

    clientCode: {

        type:String,
        required: true
    },

    DoNumber: {

        type:String,
        required: true
    },

    HSN: {

        type:String,
        required: true
    },

    count: {

        type:String,
        required: true
    },

    NoOfBags: {

        type:String,
        required: true
    },

    weightPerBag: {

        type:String,
        required: true
    },

    date: {

        type:String,
        required: true
    },
    
    time: {

        type:String,
        required: true
    },

})

module.exports = mongoose.model('Stock', StockSchema)