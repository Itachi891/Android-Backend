const { Schema, mongo, default: mongoose } = require('mongoose')

const clientSchema = Schema({

    sizingId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Sizing'
    },

    sizingName: {

        type: String,
        required: true
    },

    clientName: {

        type: String,
        required: true
    },

    clientCode: {

        type: String,
        required: true
    },
    
    password: {

        type: String,
        required: true
    },
    
    contact1: {

        type: String,
        required: true
    },
    
    contact2: {

        type: String,
        required: true
    },
    
    State: {

        type: String,
        required: true
    },
    
    city: {

        type: String,
        required: true
    },
    
    address: {

        type: String,
        required: true
    },

    stock: {

        type: mongoose.Schema.Types.ObjectId, ref:'Stock'
    }

}, {timeStamp: true})

module.exports = mongoose.model('Client', clientSchema)