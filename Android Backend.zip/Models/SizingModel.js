const { Schema, mongo, default: mongoose } = require('mongoose')

const sizingSchema = Schema({


    userName: {

        type: String,
        required: true
    },

    password: {

        type: String,
        required: true
    },

    sizingName: {

        type: String,
        required: true
    },

    ownerName: {

        type: String,
        required: true
    },

    contact1: {

        type: String,
        required: true
    },

    contact2: {

        type: String,
        required: true
    },

    state: {

        type: String,
    },

    city: {

        type: String,
    },

    address: {

        type: String,
        required: true
    },

    bankName: {
        type: String,
        required: true


    },
    accountNumber: {
        type: String,
        required: true

    },


    IFSC: {
        type: String,
        required: true

    },
    GSTIN: {
        type: String,
        required: true

    },
    PAN: {
        type: String,
        required: true

    },

    stock: {

        type: mongoose.Schema.Types.ObjectId, ref: 'Stock'
    },

    client: {

        type: mongoose.Schema.Types.ObjectId, ref: 'Client'
    }

})

module.exports = mongoose.model('Sizing', sizingSchema)