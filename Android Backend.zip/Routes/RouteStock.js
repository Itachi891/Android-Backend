const express = require('express')

const verification = require('../Middlewares/jwt_authorization')
const stockController = require('../Controllers/StockController')

const route = express.Router()

route.use(verification.verifyToken)

route.post('/insertstock', stockController.insertStock)

route.post('/displaystock', stockController.viewStock)

route.post('/editstock', stockController.editStock)

module.exports = route