const express = require('express')
const sizingController = require('../Controllers/SizingController')
const verifyToken = require('../Middlewares/jwt_authorization')

route = express.Router()

route.post('/logIn', sizingController.logIn)

route.post('/viewProfile', verifyToken.verifyToken, sizingController.viewProfile)

route.put('/editProfile', verifyToken.verifyToken, sizingController.editProfile)


// for admin
// route.post('/createSizing', sizingController.createSizing)

// route.post('/deleteSizing', sizingController.deleteSizing)

module.exports = route