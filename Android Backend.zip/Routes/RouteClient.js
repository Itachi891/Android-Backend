const express = require('express')
const client = require('../Controllers/ClientController')
const verifyToken = require('../Middlewares/jwt_authorization')

route = express.Router()

route.use(verifyToken.verifyToken)

route.post('/createclient', client.createClient)

route.post('/displayclient', client.displayClient)

route.put('/editclient', client.editClinet)

route.post('/deleteclient', client.deleteClient)


module.exports = route