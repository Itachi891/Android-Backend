const express = require('express')
const bodyParser = require('body-parser')
const mongoose = require('mongoose')

// custom imports
const routerSizing = require('./Routes/RouteSizing')
const routerClient = require('./Routes/RouteClient')
const routerStock = require('./Routes/RouteStock')
const keys = require('./Configurations/Strings')

app = express()

// app.use(express.json())
app.use(bodyParser.json())
// app.use(bodyParser.urlencoded({ extended : true }))

// connect to db
mongoose.connect(keys.dbString).then ( console.log('connected') )

// routes middleware
app.use(routerSizing)
app.use(routerClient)
app.use(routerStock)

app.listen(keys.portNumber, () => {

    console.log('server is up at ' + keys.portNumber)
})