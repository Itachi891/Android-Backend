const sizing = require('../Models/SizingModel')
const client = require('../Models/ClientModel')
const stock = require('../Models/StockModel')


// insert stock ==> OK
const insertStock = async (req, res) => {

    const sizingId = req.user.id
    const clients = await client.find({ sizingId })

    if (clients) {

        clients.forEach(async (user) => {

            // This check is to insert the stock to the respected client code
            if (user.clientCode === req.body.clientCode) {

                const { clientCode, DoNumber, HSN, count, NoOfBags, weightPerBag, date, time } = req.body

                const data = new stock({ clientCode, sizingId, clientId: user._id, DoNumber, HSN, count, NoOfBags, weightPerBag, date, time })

                const stockData = await data.save()
                res.status(201).send(stockData)
            } else
                res.status(403).send('worng client code')
        })

    } else
        res.status(400).send('Access Denied')

}

// view stock
const viewStock = async (req, res) => {

    try {

        const sizingId = req.user.id
        const clientCode = req.body.clientCode

        const clients = await client.find({ sizingId })

        if (clients) {

            let stockData = null
            clients.forEach(async (user) => {

                const clientId = user._id

                const stocks = await stock.find({ clientId })

                stocks.forEach((data) => {

                    if (data.clientCode == clientCode) {

                        console.log(data)
                        stockData = data
                    } else
                        res.status(403).send('wrong clinet code')
                })
            })
            console.log(stockData)
            res.status(200).send(stockData)

        } else
            res.status(403).send('not found')

    }
    catch (error) {

        console.log(error.message)
        res.status(500).json({ message: 'Server Error' })
    }
}

// edit stock
const editStock = async (req, res) => {

    // in android the stock will be sent with its id use it to identify whcih stock client wnat to edit

}


module.exports = {

    insertStock, viewStock,
    editStock
}