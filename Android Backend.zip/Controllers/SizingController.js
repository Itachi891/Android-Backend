const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')

const keys = require('../Configurations/Strings')
const sizing = require('../Models/SizingModel')

// LogIn ==> ok
const logIn = async (req, res) => {

    let userName = req.body.userName
    const pass = req.body.password


    try {

        const user = await sizing.findOne({ userName })

        if (!user) {

            res.status(404).send()
        } else {

            const isMatched = await bcrypt.compare(pass, user.password)

            if (!isMatched) {

                res.status(403).json({ message: "Invalid credintilas" })
            } else {

                const token = jwt.sign({ id: user._id }, keys.jwt_secretKey)
                console.log(token)
                res.status(200).send(JSON.stringify(token))
            }
        }


    } catch (error) {

        res.status(500).json({ message: error.message }).send()
    }
}

// View profile ==> OK
const viewProfile = async (req, res) => {

    try {

        const sizingId = req.user.id
        const profile = await sizing.findOne({ _id: sizingId })
        if (!profile)
            res.status(404).json({ status: "user not found" }).send()
        else
            res.status(200).json({ data: profile }).send()

    } catch (error) {

        console.log(error.message)
        res.status(500).json({ message: error.message }).send()
    }
}

// Edit prfile
const editProfile = async (req, res) => {

    try {

        // check the token then update
        const id = req.user.id
        const hashPass = await bcrypt.hash(req.body.password, keys.hashTime)

        const updateSizing = {

            ownerName: req.body.ownerName,
            sizingName: req.body.sizingName,
            password: hashPass,
            constact1: req.body.constact1,
            constact2: req.body.constact2,
            state: req.body.state,
            city: req.body.city,
            address: req.body.address,
            bankName: req.body.bankName,
            accountNumber: req.body.accountNumber,
            IFSC: req.body.IFSC,
            GSTIN: req.body.GSTIN,
            PAN: req.body.PAN
        }

    
        const updatedProfile = await sizing.findOneAndUpdate({_id: id}, updateSizing)
        
        if (!updatedProfile)
        res.status(404).json({ status: "user not found" }).send()

        res.status(200).json({ status: "updated" }).send()

    } catch (error) {

        console.log(error.message)
        res.status(500).json({ message: error.message }).send()
    }
}

module.exports = {

    logIn, viewProfile,
    editProfile,
    // createSizing,
    // deleteSizing
}