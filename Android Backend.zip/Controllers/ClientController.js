const bcrypt = require('bcryptjs')
const client = require('../Models/ClientModel')
const sizing = require('../Models/SizingModel')
const keys = require('../Configurations/Strings')

// Create client ==> OK
const createClient = async (req, res) => {

    try {

        const user = req.user.id
        const clientCode = req.body.clientCode

        const clinetData = await client.findOne({ clientCode })

        if (clinetData)
            res.status(409).send('Clinet already presert, try another code')
        else {

            const hashPass = await bcrypt.hash(req.body.password, keys.hashTime)

            const clientProfile = new client({
                sizingId: user,
                clientName: req.body.clientName,
                clientCode: req.body.clientCode,
                sizingName: req.body.sizingName,
                password: hashPass,
                contact1: req.body.contact1,
                contact2: req.body.contact2,
                State: req.body.state,
                city: req.body.city,
                address: req.body.address,
            })

            const profile = await clientProfile.save()
            res.status(201).json({ message: 'inserted', data: profile })
        }
    } catch (error) {

        console.log(error.message)
        res.status(500).json({ message: 'Server Error' })
    }
}

// display clients ==> OK
const displayClient = async (req, res) => {

    try {

        const id = req.user.id

        const clients = await client.find({ user: id })

        if (clients)
            res.status(200).json({ clients: [clients] })
        else
            res.status(400).send('Access denied')

    } catch (error) {

        console.log(error.message)
        res.status(500).json({ message: 'Server Error' })
    }
}

// editClient ==> OK
const editClinet = async (req, res) => {

    try {

        const id = req.user.id

        const clientData = await client.find({ user: id })

        if (clientData) {

            const { clientCode, clientName, password, contact1, contact2, state, city, address } = req.body

            const hashPass = await bcrypt.hash(password, keys.hashTime)

            const data = { clientName, password: hashPass, contact1, contact2, state, city, address }

            const updatedData = await client.findOneAndUpdate({ clientCode: clientCode }, data)

            if (updatedData) {

                res.status(200).send('Updated')
            } else {
                res.status(400).send('Not updated')
            }
        } else
            res.status(400).send('Access denied')

    } catch (error) {

        res.status(500).json({ message: 'server Error' })
    }
}


// delete clients ==> OK
const deleteClient = async (req, res) => {

    try {

        const id = req.user.id

        const clinets = await client.find({ user: id })

        if (clinets) {

            const clientCode = req.body.clientCode
            const data = await client.deleteOne({ clientCode })
            res.status(200).send('Deleted')

        } else
            res.status(400).send('Access denied')
    }
    catch (error) {

        res.status(500).json({ message: 'Server Error' })
    }
}

module.exports = {

    createClient, displayClient,
    editClinet, deleteClient
}