const dbString = 'mongodb://127.0.0.1:27017/Sizing'
const portNumber = 3002
const hashTime = 10
const jwt_secretKey = "//Hassan"


module.exports = {

    dbString, portNumber,
    hashTime,
    jwt_secretKey
}