const jwt = require('jsonwebtoken')
const keys = require('../Configurations/Strings')

const verifyToken = async (req, res, next) => {

    // const jsonString = `{"token": "${req.body.token}"}`
    // const auth = JSON.parse(jsonString)
try {
    
    const jwtToken = req.body.jwt

    if (jwtToken) {

        const token = jwt.verify(jwtToken, keys.jwt_secretKey)

        if (token) {

            req.user = token
            next()
            return req.user
        } else
            res.status(404).json({ message: "incorrect token " })

    } else {

        res.status(400).send('Something went wrong, log out then logIn again')
    }
} catch (error) {

    console.log(error.message)
    res.status(400).send('Internal Server Error')
}


}

module.exports = {

    verifyToken
}